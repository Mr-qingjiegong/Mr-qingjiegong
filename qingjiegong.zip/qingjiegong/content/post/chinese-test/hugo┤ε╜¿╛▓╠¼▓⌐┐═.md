---
title: hugo搭建静态博客
description: hugo部署GitHub博客
date: 2024-09-17
slug: test-chinese
image: 
categories: images/hugo.png
    - hugo
    - 博客
---



# 简介

为啥采用hugo，不采用hexo框架？

问题很好，没办法解释，两个框架都使用过，个人感觉hexo在主题上更丰富些，hugo在维护上更方便点，所以还是用回了hugo



# 安装hugo

官网：**[The world’s fastest framework for building websites | Hugo (gohugo.io)](https://gohugo.io/)**